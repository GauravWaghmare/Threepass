from data import attributes, model, speeches
import helpers

def GetCorrectAnswerResponse(handler_input):
    sessionAttributes = handler_input.attributes_manager.session_attributes
    listOfPlayers = sessionAttributes[attributes.LIST_PLAYERS]
    slots = handler_input.request_envelope.request.intent.slots
    turnOfPlayer = slots.get(attributes.TURN_KEY).value
    noOfPlayer = slots.get(attributes.NO_PLAYERS)
    turnOfPlayer = (turnOfPlayer+1)%noOfPlayer
    counter = sessionAttributes[attributes.COUNTER_KEY]
    if turnOfPlayer==0:
        correctAnswer = helpers.GetCorrectAnswer(counter+1)
        counter += 2
        sessionAttributes[attributes.TURN_KEY] = 1
        sessionAttributes[attributes.COUNTER_KEY] = counter
        response_message = speeches.MYTURN_MESSAGEFORMAT.format(correctAnswer, listOfPlayers[1])
    else:
        counter += 1
        sessionAttributes[attributes.TURN_KEY] = turnOfPlayer
        sessionAttributes[attributes.COUNTER_KEY] = counter
        response_message = speeches.PLAYERSTURN_MESSAGEFORMAT.format(listOfPlayers[turnOfPlayer])
    handler_input.response_builder.speak(response_message)
    return handler_input.response_builder.response


def GetIncorrectAnswerResponse(handler_input):
    sessionAttributes = handler_input.attributes_manager.session_attributes
    listOfPlayers = sessionAttributes[attributes.LIST_PLAYERS]
    slots = handler_input.request_envelope.request.intent.slots
    turnOfPlayer = slots.get(attributes.TURN_KEY).value
    counter = sessionAttributes[attributes.COUNTER_KEY]
    del listOfPlayers[turnOfPlayer]
    noOfPlayer = slots.get(attributes.NO_PLAYERS)
    noOfPlayer -= 1
    if noOfPlayer==0:
        response_message = speeches.IWIN_MESSAGE
    else:
        turnOfPlayer = turnOfPlayer%noOfPlayer
        counter += 1
        sessionAttributes[attributes.TURN_KEY] = turnOfPlayer
        sessionAttributes[attributes.COUNTER_KEY] = counter
        response_message = speeches.INCORRECTANSWER_MESSAGEFORMAT.format(listOfPlayers[turnOfPlayer])
    handler_input.response_builder.speak(response_message)
    return handler_input.response_builder.response
    
